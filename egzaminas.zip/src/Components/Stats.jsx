function Stats({ stats, groupStats }) {

    return (
        <div>
            <div className='statistic-results'>
                <span>book count: <i>{stats.count}</i></span>
                {/* <span>Sum: <i>{stats.price.toFixed(2)}</i> </span> */}
                <span>Average book price: <i>{stats.average.toPrecision(3)}</i> </span>
            </div>


        </div>
    )
}
export default Stats;